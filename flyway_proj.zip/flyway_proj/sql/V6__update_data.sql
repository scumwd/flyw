UPDATE hub
SET id = id + 50000
WHERE id <= 950000;
